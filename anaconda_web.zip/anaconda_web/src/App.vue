<script setup>
import { ref, onMounted, computed } from 'vue'

// === STATE ===
const chats = ref([])
const selectedChat = ref(null)
const messages = ref([])
const organizations = ref([])
const loading = ref(true)
const error = ref(null)
const showCreateContactModal = ref(false)

// Form data for creating contact
const newContactForm = ref({
  name: '',
  position: '',
  org_id: null,
  source: null,
  sender_id: null
})

// === API URL ===
const getAPIUrl = () => {
  if (typeof window !== 'undefined') {
    const host = window.location.hostname
    if (host === 'localhost' || host === '127.0.0.1') {
      return 'http://localhost:8000/api'
    }
    return `http://${host}:8000/api`
  }
  return '/api'
}

const API_URL = getAPIUrl()

// === COMPUTED ===
const isContactKnown = computed(() => {
  return selectedChat.value?.is_known || false
})

const selectedChatMessages = computed(() => {
  if (!selectedChat.value) return []
  return messages.value.filter(msg => msg.sender_id === selectedChat.value.sender_id)
})

// === METHODS ===

const fetchChats = async () => {
  try {
    const res = await fetch(`${API_URL}/chats`)
    if (!res.ok) throw new Error(`HTTP ${res.status}`)
    const data = await res.json()
    chats.value = data || []
    error.value = null
  } catch (e) {
    error.value = `Ошибка загрузки диалогов: ${e.message}`
    console.error("Fetch chats error:", e)
  }
}

const fetchMessages = async () => {
  try {
    const res = await fetch(`${API_URL}/messages`)
    if (!res.ok) throw new Error(`HTTP ${res.status}`)
    const data = await res.json()
    messages.value = data || []
  } catch (e) {
    console.error("Fetch messages error:", e)
  }
}

const fetchOrganizations = async () => {
  try {
    const res = await fetch(`${API_URL}/organizations`)
    if (!res.ok) throw new Error(`HTTP ${res.status}`)
    const data = await res.json()
    organizations.value = data || []
  } catch (e) {
    console.error("Fetch organizations error:", e)
  }
}

const selectChat = (chat) => {
  selectedChat.value = chat
}

const openCreateContactModal = () => {
  if (!selectedChat.value) return
  newContactForm.value = {
    name: selectedChat.value.name || '',
    position: '',
    org_id: null,
    source: selectedChat.value.source,
    sender_id: selectedChat.value.sender_id
  }
  showCreateContactModal.value = true
}

const createContact = async () => {
  if (!newContactForm.value.name) {
    alert('Укажите имя контакта')
    return
  }

  try {
    const res = await fetch(`${API_URL}/contacts`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newContactForm.value)
    })
    
    if (!res.ok) {
      const error = await res.json()
      throw new Error(error.message || 'Ошибка создания контакта')
    }

    const data = await res.json()
    console.log('✓ Contact created:', data)
    
    showCreateContactModal.value = false
    
    // Обновляем чаты
    await fetchChats()
    
    // Перевыбираем диалог, чтобы обновить статус
    if (selectedChat.value) {
      const updated = chats.value.find(c => c.sender_id === selectedChat.value.sender_id)
      if (updated) {
        selectedChat.value = updated
      }
    }
  } catch (e) {
    alert(`Ошибка: ${e.message}`)
  }
}

// === LIFECYCLE ===

onMounted(async () => {
  try {
    await Promise.all([fetchChats(), fetchMessages(), fetchOrganizations()])
    
    // Автоматически выбираем первый диалог
    if (chats.value.length > 0) {
      selectedChat.value = chats.value[0]
    }
  } finally {
    loading.value = false
  }

  // Периодически обновляем
  setInterval(() => {
    fetchChats()
    fetchMessages()
  }, 2000)
})

// === COLOR HELPERS ===
const getSourceColor = (source) => {
  return source === 'telegram' ? 'border-sky-500' : 'border-red-600'
}

const getSourceBg = (source) => {
  return source === 'telegram' ? 'bg-sky-50' : 'bg-red-50'
}

const getSourceIcon = (source) => {
  return source === 'telegram' ? '💬' : '📧'
}
</script>

<template>
  <div class="flex h-screen bg-slate-50">
    <!-- HEADER -->
    <div class="fixed top-0 left-0 right-0 bg-slate-900 text-white shadow-lg z-10">
      <div class="max-w-full px-6 py-4">
        <div class="flex items-center justify-between">
          <div class="flex items-center gap-3">
            <span class="text-2xl">🐍</span>
            <div>
              <h1 class="text-xl font-bold">Anaconda</h1>
              <p class="text-xs text-sky-300">MVP 1.0 | Unified Sales Core</p>
            </div>
          </div>
          <div class="text-right text-xs text-slate-400">
            API: {{ API_URL }}
          </div>
        </div>
      </div>
    </div>

    <!-- SIDEBAR (Диалоги) -->
    <div class="fixed left-0 top-16 bottom-0 w-96 bg-white border-r border-slate-200 overflow-y-auto">
      <div class="p-4">
        <h2 class="font-bold text-slate-900 mb-4">Входящие диалоги</h2>
        
        <div v-if="loading" class="text-slate-500 text-sm">Загрузка...</div>
        <div v-else-if="error" class="text-red-600 text-sm">{{ error }}</div>
        <div v-else-if="chats.length === 0" class="text-slate-500 text-sm">Нет диалогов</div>
        
        <div v-for="chat in chats" :key="chat.sender_id" @click="selectChat(chat)"
             :class="[
               'p-3 mb-2 rounded border-l-4 cursor-pointer transition',
               getSourceBg(chat.source),
               getSourceColor(chat.source),
               selectedChat?.sender_id === chat.sender_id ? 'ring-2 ring-blue-500' : 'hover:bg-opacity-75'
             ]">
          <div class="flex items-start justify-between">
            <div class="flex-1 min-w-0">
              <div class="flex items-center gap-2">
                <span>{{ getSourceIcon(chat.source) }}</span>
                <div class="truncate">
                  <p class="font-semibold text-slate-900 truncate">{{ chat.name }}</p>
                  <p class="text-xs text-slate-600 truncate">{{ chat.position || chat.sender_id }}</p>
                </div>
              </div>
              <p class="text-xs text-slate-500 mt-1 line-clamp-2">{{ chat.last_message.text }}</p>
            </div>
            <div class="ml-2 flex-shrink-0">
              <span v-if="chat.unread_count > 0" class="bg-red-600 text-white text-xs rounded-full px-2 py-0.5">
                {{ chat.unread_count }}
              </span>
              <span v-if="chat.is_known" class="text-green-600 text-xs ml-1">✓</span>
              <span v-else class="text-red-600 text-xs ml-1">!</span>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- MAIN CONTENT -->
    <div class="fixed left-96 right-0 top-16 bottom-0 flex flex-col bg-white">
      <!-- CHAT HEADER -->
      <div v-if="selectedChat" class="bg-slate-100 border-b border-slate-200 p-4 flex items-center justify-between">
        <div>
          <h2 class="text-xl font-bold"
              :class="isContactKnown ? 'text-green-600' : 'text-red-600'">
            {{ selectedChat.name }}
          </h2>
          <p v-if="isContactKnown" class="text-sm text-slate-600">
            {{ selectedChat.position }} | {{ selectedChat.organization }}
          </p>
          <p v-else class="text-sm text-red-600 font-semibold">
            Неизвестный контакт
          </p>
        </div>
        <button 
          v-if="!isContactKnown"
          @click="openCreateContactModal"
          class="px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700 transition font-semibold">
          + СОЗДАТЬ КОНТАКТ
        </button>
        <button v-else class="px-4 py-2 bg-slate-300 text-slate-900 rounded hover:bg-slate-400 transition">
          КАРТОЧКА
        </button>
      </div>

      <div v-else class="flex items-center justify-center h-full text-slate-500">
        Выберите диалог
      </div>

      <!-- MESSAGES -->
      <div v-if="selectedChat" class="flex-1 overflow-y-auto p-4 space-y-3">
        <div v-for="msg in selectedChatMessages" :key="msg.id"
             :class="[
               'p-3 rounded',
               msg.source === 'telegram' ? 'bg-sky-50 border-l-4 border-sky-500' : 'bg-red-50 border-l-4 border-red-600'
             ]">
          <div class="flex justify-between items-start mb-1">
            <span class="font-semibold text-slate-900">{{ msg.sender }}</span>
            <span class="text-xs text-slate-500">{{ new Date(msg.created_at).toLocaleTimeString() }}</span>
          </div>
          <p class="text-slate-700 text-sm whitespace-pre-wrap">{{ msg.text }}</p>
        </div>
      </div>
    </div>

    <!-- CREATE CONTACT MODAL -->
    <div v-if="showCreateContactModal" class="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div class="bg-white rounded-lg p-6 max-w-md w-full mx-4">
        <h3 class="text-xl font-bold mb-4">Создать контакт</h3>
        
        <div class="space-y-4">
          <div>
            <label class="block text-sm font-semibold mb-1">ФИО *</label>
            <input v-model="newContactForm.name" type="text" class="w-full border border-slate-300 rounded px-3 py-2">
          </div>
          
          <div>
            <label class="block text-sm font-semibold mb-1">Должность</label>
            <input v-model="newContactForm.position" type="text" class="w-full border border-slate-300 rounded px-3 py-2">
          </div>
          
          <div>
            <label class="block text-sm font-semibold mb-1">Организация</label>
            <select v-model="newContactForm.org_id" class="w-full border border-slate-300 rounded px-3 py-2">
              <option :value="null">Не выбрана</option>
              <option v-for="org in organizations" :key="org.id" :value="org.id">
                {{ org.name }}
              </option>
            </select>
          </div>
          
          <div class="flex gap-3 pt-4">
            <button @click="showCreateContactModal = false" class="flex-1 px-4 py-2 bg-slate-300 text-slate-900 rounded hover:bg-slate-400">
              Отмена
            </button>
            <button @click="createContact" class="flex-1 px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 font-semibold">
              Сохранить
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.line-clamp-2 {
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}
</style>
